
package com.mycompany.studentgradecalculator;


public class StudentGradeCalculator {

    public static void main(String[] args) {
        gradeCalculator g1=new gradeCalculator();
        g1.setVisible(true);
    }
}
